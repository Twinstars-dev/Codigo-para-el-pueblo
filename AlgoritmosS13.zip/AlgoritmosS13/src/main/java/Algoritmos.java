package main.java;

public class Algoritmos {

    // Recursividad directa: el metodo se llama a si mismo.
    public static long factorialDirecto(int n) {
        if (n < 0 || n > 20) {
            throw new IllegalArgumentException("El numero debe estar entre 0 y 20");
        }
        if (n == 0) {
        	return 1;
        }
        return n * factorialDirecto(n - 1);
    }

    // Recursividad indirecta: estos dos metodos se llaman entre si.
    public static boolean esPar(int n) {
        if (n < 0) {
        	throw new IllegalArgumentException("El numero no puede ser negativo");
        }
        if (n == 0) {
        	return true;
        }
        return esImpar(n - 1);
    }

    public static boolean esImpar(int n) {
        if (n < 0) {
        	throw new IllegalArgumentException("El numero no puede ser negativo");
        }
        if (n == 0) {
        	return false;
        }
        return esPar(n - 1);
    }

    //Iteracion: calcula el factorial utilizando un ciclo for.
    public static long factorialIterativo(int n) {
        if (n < 0 || n > 20) {
            throw new IllegalArgumentException("El numero debe estar entre 0 y 20");
        }
        long resultado = 1;
        for (int i = 1; i <= n; i++) {
            resultado *= i;
        }
        return resultado;
    }
}
