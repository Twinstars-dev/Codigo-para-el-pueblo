package main.java;

public class Principal {

    public static void main(String[] args) {
        int numero = 5;

        System.out.println("==================================");
        System.out.println("               MENU               ");
        System.out.println("==================================");

        System.out.println("\n1. RECURSIVIDAD DIRECTA");
        System.out.println("Factorial de " + numero + ": "+ Algoritmos.factorialDirecto(numero));

        System.out.println("\n2. RECURSIVIDAD INDIRECTA");
        System.out.println("¿8 es par? " + Algoritmos.esPar(8));
        System.out.println("¿5 es par? " + Algoritmos.esPar(5));
        System.out.println("¿7 es impar? " + Algoritmos.esImpar(7));

        System.out.println("\n3. ITERACION");
        System.out.println("Factorial de " + numero + ": "+ Algoritmos.factorialIterativo(numero));
    }
}
